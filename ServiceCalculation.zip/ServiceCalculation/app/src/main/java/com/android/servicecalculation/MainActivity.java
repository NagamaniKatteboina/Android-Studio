package com.android.servicecalculation;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.android.servicecalculation.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonResultReceiver.setOnClickListener(view ->  {
            try {
                int num1 = Integer.parseInt(binding.editTextNum1.getText().toString());
                int num2 = Integer.parseInt(binding.editTextNum2.getText().toString());
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("num1", num1);
                intent.putExtra("num2", num2);
                intent.putExtra("receiver", resultReceiver);
                startService(intent);
            } catch (NumberFormatException e) {
                Log.e(TAG, "Invalid input", e);
                binding.textViewResult.setText("Invalid input while calculating result using ResultReceiver");
            }

        });

        // Register the broadcast receiver
        registerReceiver(resultBroadcastReceiver, new IntentFilter("com.example.myserviceapp.RESULT_BROADCAST"));
        binding.buttonBroadcastReceiver.setOnClickListener(view ->  {
            try {
                int num1 = Integer.parseInt(binding.editTextNum1.getText().toString());
                int num2 = Integer.parseInt(binding.editTextNum2.getText().toString());
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("num1", num1);
                intent.putExtra("num2", num2);
                startService(intent);
            } catch (NumberFormatException e) {
                Log.e(TAG, "Invalid input", e);
                binding.textViewResult.setText("Invalid input while calculating result using broadcast");
            }

        });
    }

    ResultReceiver resultReceiver = new ResultReceiver(new Handler()) {
        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {
            super.onReceiveResult(resultCode, resultData);
            if (resultCode == RESULT_OK && resultData != null) {
                int result = resultData.getInt("result");
                binding.textViewResult.setText("Total price from Result Receiver:" + result);
            }
        }
    };

    // BroadcastReceiver implementation
    private final BroadcastReceiver resultBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction().equals("com.example.myserviceapp.RESULT_BROADCAST")) {
                int result = intent.getIntExtra("result", 0);
                binding.textViewResult.setText("Total price from BroadcastReceiver:"+ result);
            } else {
                binding.textViewResult.setText("intent is null");
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(resultBroadcastReceiver);
    }
}