package com.android.servicecalculation;

import static android.app.Activity.RESULT_OK;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ResultReceiver;
import android.util.Log;

public class MyService extends Service {

    private static final String TAG = "MyService";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Thread calculationThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(500); // Simulate some work
                    int quantity = intent.getIntExtra("num1", 0);
                    int price = intent.getIntExtra("num2", 0);
                    int totalPrice = price * quantity;


                        ResultReceiver receiver = intent.getParcelableExtra("receiver");
                        if (receiver != null) {
                            Bundle bundle = new Bundle();
                            bundle.putInt("result", totalPrice);
                            receiver.send(RESULT_OK, bundle);
                            Log.d(TAG, "Result sent via ResultReceiver");
                        } else {
                            //Log.e(TAG, "ResultReceiver is null");
                            Intent broadcastIntent = new Intent("com.example.myserviceapp.RESULT_BROADCAST");
                            broadcastIntent.setAction("com.example.myserviceapp.RESULT_BROADCAST");
                            broadcastIntent.putExtra("result", totalPrice);
                            sendBroadcast(broadcastIntent);
                            Log.d(TAG, "Result sent via BroadcastReceiver");
                        }

                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

        });
        calculationThread.start();

        // Stop the service after the task is done
        stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}