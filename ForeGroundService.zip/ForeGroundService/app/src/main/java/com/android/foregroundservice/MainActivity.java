package com.android.foregroundservice;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.foregroundservice.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.startButton.setOnClickListener(v -> {
            String name = binding.editName.getText().toString();
            String phoneNumber = binding.editPhone.getText().toString();
            String email = binding.editEmail.getText().toString();
            String password = binding.editPassword.getText().toString();
            Intent intent = new Intent(this,DetailsService.class);
            intent.putExtra("name",name);
            intent.putExtra("phoneNumber",phoneNumber);
            intent.putExtra("email",email);
            intent.putExtra("password",password);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            }
        });

        binding.clearButton.setOnClickListener(v -> {
            binding.textView.setText("");
            binding.editName.setText("");
            binding.editPhone.setText("");
            binding.editEmail.setText("");
            binding.editPassword.setText("");
            binding.startButton.setText("Start Foreground");
        });
    }

    @Override
    protected void onNewIntent(@NonNull Intent intent) {
        super.onNewIntent(intent);
        if (intent!=null) {
            String name = intent.getStringExtra("name");
            String phoneNumber = intent.getStringExtra("phoneNumber");
            String email = intent.getStringExtra("email");
            String password = intent.getStringExtra("password");

            if (name != null && phoneNumber != null && email != null && password!=null) {
                binding.textView.setText("User Details");
                binding.editName.setText("Name: "+name);
                binding.editPhone.setText("PhoneNumber: "+phoneNumber);
                binding.editEmail.setText("Email: "+email);
                binding.editPassword.setText("Password: "+password);
                binding.startButton.setText("again StartForeground");
            }
        }
    }
}