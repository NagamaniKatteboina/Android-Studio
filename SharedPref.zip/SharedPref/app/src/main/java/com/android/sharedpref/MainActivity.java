package com.android.sharedpref;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Button button;
    EditText editEmail,editPassword;

    String Login_Status = "";

    public static String sharedPref = "myPref";
    public static String LOGIN_STATUS_KEY = "login_status_key";
    public static String EMAIL = "login_email_key";
    public static String PASS = "login_pass_key";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        button = findViewById(R.id.button);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);

        sharedPreferences = getSharedPreferences(sharedPref,MODE_PRIVATE);
        editor = sharedPreferences.edit();

        String lastStatus = sharedPreferences.getString(LOGIN_STATUS_KEY,"");
        if (lastStatus.equals("Login_Done")) {
            Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
            startActivity(intent);
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doLogin();
            }
        });
    }

    private void doLogin() {
        String email = editEmail.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        Timer timerObj =  new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Login_Status = "Login_Done";
                editor.putString(LOGIN_STATUS_KEY,Login_Status);
                editor.putString(EMAIL,email);
                editor.putString(PASS,password);
                editor.commit();
                Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(intent);
            }
        };
        timerObj.schedule(timerTask,0,400);
        

    }

}