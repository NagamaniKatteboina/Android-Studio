package com.android.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private DbHelper helper;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        helper = new DbHelper(this,"mydb",null,1);
        findViewById(R.id.btnInsert).setOnClickListener(this::click);
        findViewById(R.id.btnUpdate).setOnClickListener(this::click);
        findViewById(R.id.btnDelete).setOnClickListener(this::click);
        findViewById(R.id.btnDisplay).setOnClickListener(this::click);
    }

    public void click(View view) {
        if(view.getId() == R.id.btnInsert)
            insert();
        if(view.getId() == R.id.btnUpdate)
            update();
        if(view.getId() == R.id.btnDelete)
            delete();
        if(view.getId() == R.id.btnDisplay)
            display();
    }

    private  void insert() {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",getMyName());
        values.put("emailId",getMyEmailId());
        db.insert("student",null,values);
        Toast.makeText(this, "record inserted", Toast.LENGTH_SHORT).show();
        db.close();
    }

    private  void update() {
        SQLiteDatabase db = helper.getWritableDatabase();
        String table = "student";
        ContentValues values = new ContentValues();
        values.put("emailId",getMyEmailId());
        String whereClause = "name = ?";
        String[] whereArgs = {String.valueOf(getMyName())};
        db.update(table,values,whereClause,whereArgs);
        Toast.makeText(this, "record updated", Toast.LENGTH_SHORT).show();
        db.close();
    }

    private  void delete() {
        SQLiteDatabase db = helper.getWritableDatabase();
        String table = "student";
        String whereClause = "name = ?";
        String[] whereArgs = {String.valueOf(getMyName())};
        db.delete(table,whereClause,whereArgs);
        Toast.makeText(this, "record deleted", Toast.LENGTH_SHORT).show();
        db.close();
    }

    private  void display() {
        textView = findViewById(R.id.textDbInfo);
        SQLiteDatabase db = helper.getReadableDatabase();
        //pulls the data from database
        String table = "student";
        String[] columns = null;
        String selection = null;
        String[] selectionArgs = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;
        Cursor cursor = db.query(table,columns,selection,selectionArgs,groupBy,having,orderBy);
        if (cursor != null && cursor.moveToFirst()) {
            StringBuilder stringbuilder = new StringBuilder();
            do {
                @SuppressLint("Range")
                String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range")
                String emailId = cursor.getString(cursor.getColumnIndex("emailId"));
                Log.d("@studentdata", "Name :" + name + " emailId :" + emailId);
                stringbuilder.append("Name :" + name + " emailId :" + emailId + "\n");
            } while (cursor.moveToNext());
            textView.setText(stringbuilder.toString());
        } else {
            textView.setText("No records found");
        }
        db.close();
    }

    private String getMyName() {
        return ((EditText)findViewById(R.id.edMyName)).getText().toString();
    }

    private  String getMyEmailId() {
        return ((EditText)findViewById(R.id.edEmailId)).getText().toString();
    }

}