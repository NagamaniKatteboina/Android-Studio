package com.example.videouploadvolley;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;
import android.Manifest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_VIDEO_PICK = 1;
    private static final int REQUEST_PERMISSION = 100;
    private VideoView videoView;
    private Uri videoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSelectVideo = findViewById(R.id.btnSelectVideo);
        Button btnUploadVideo = findViewById(R.id.btnUploadVideo);
        videoView = findViewById(R.id.videoView);

        btnSelectVideo.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION);
            } else {
                selectVideo();
            }
        });

        btnUploadVideo.setOnClickListener(v -> {
            if (videoUri != null) {
                uploadVideo(videoUri);
            } else {
                Toast.makeText(this, "Please select a video first", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void selectVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_VIDEO_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VIDEO_PICK && resultCode == RESULT_OK && data != null) {
            videoUri = data.getData();
            videoView.setVideoURI(videoUri);
            videoView.start();
        }
    }

    private void uploadVideo(Uri videoUri) {
        String uploadUrl = "https://jsonplaceholder.typicode.com/posts"; // Replace with your server URL
        String encodedUrl = Base64.encodeToString(uploadUrl.getBytes(), Base64.DEFAULT);
        String decodedUrl = new String(Base64.decode(encodedUrl, Base64.DEFAULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, decodedUrl,
                response -> Toast.makeText(MainActivity.this, "Upload successful", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(MainActivity.this, "Upload failed: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("video", videoUri.toString()); // This is just a placeholder. You need to handle file upload properly.
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }
}






/*
public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_VIDEO_PICK = 1;
    private static final int REQUEST_PERMISSION = 100;
    private VideoView videoView;
    private Uri videoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSelectVideo = findViewById(R.id.btnSelectVideo);
        Button btnUploadVideo = findViewById(R.id.btnUploadVideo);
        videoView = findViewById(R.id.videoView);

        btnSelectVideo.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION);
            } else {
                selectVideo();
            }
        });

        btnUploadVideo.setOnClickListener(v -> {
            if (videoUri != null) {
                uploadVideo(videoUri);
            } else {
                Toast.makeText(this, "Please select a video first", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void selectVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_VIDEO_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VIDEO_PICK && resultCode == RESULT_OK && data != null) {
            videoUri = data.getData();
            videoView.setVideoURI(videoUri);
            videoView.start();
        }
    }

    private void uploadVideo(Uri videoUri) {
        String uploadUrl = "https://example.com/upload"; // Replace with your server URL
        String encodedUrl = Base64.encodeToString(uploadUrl.getBytes(), Base64.DEFAULT);

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, encodedUrl,
                response -> Toast.makeText(MainActivity.this, "Upload successful", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(MainActivity.this, "Upload failed: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                String encodedVideoUri = Base64.encodeToString(videoUri.toString().getBytes(), Base64.DEFAULT);
                params.put("video", encodedVideoUri); // Encode the video URI using Base64
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }
}*/
