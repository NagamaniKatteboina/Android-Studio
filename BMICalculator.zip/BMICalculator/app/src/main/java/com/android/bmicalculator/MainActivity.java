package com.android.bmicalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textAge = findViewById(R.id.age);
        EditText editAge = findViewById(R.id.editAge);
        TextView textWeight = findViewById(R.id.weight);
        EditText editWeight = findViewById(R.id.editWeight);
        TextView textHeight = findViewById(R.id.height);
        EditText editHeight = findViewById(R.id.editheight);
        Button button = findViewById(R.id.button);
        TextView yourBmiIs = findViewById(R.id.bmi);
        TextView calculatedBMI = findViewById(R.id.calculatedBMI);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String age = editAge.getText().toString();
                String stringWeight = editWeight.getText().toString();
                double weight = Double.parseDouble(stringWeight);
                String stringHeight = editHeight.getText().toString();
                double heightInCm = Double.parseDouble(stringHeight);
                double heightInMeter = heightInCm/100;
                Toast.makeText(MainActivity.this, "Your BMI Calculated " +
                        "according to the age "+age+" with respect to the Weight "
                        +stringWeight+" and Height "+stringHeight,Toast.LENGTH_LONG).show();
                double bmi = weight/(heightInMeter*heightInMeter);
                calculatedBMI.setText("" + bmi);
                editAge.setText("");
                editWeight.setText("");
                editHeight.setText("");

            }
        });
    }
}