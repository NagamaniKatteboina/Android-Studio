package com.android.sendingemail;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText editSend,editSubject,editBody;

    TextView textSendTo,textSubject,textBody;
    Button button;
    String sentTo,subject,body;

    String[] addresses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textSendTo = findViewById(R.id.textTo);
        textSubject = findViewById(R.id.textSubject);
        textBody  = findViewById(R.id.textBody);

        editSend = findViewById(R.id.editSendTo);
        editSubject = findViewById(R.id.editSubject);
        editBody = findViewById(R.id.editBody);

        button = findViewById(R.id.buttonSend);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sentTo = editSend.getText().toString();
                subject = editSubject.getText().toString();
                body = editBody.getText().toString();

                
                addresses = sentTo.split(",");

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL, addresses);
                i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra(Intent.EXTRA_TEXT,body);
                if(i.resolveActivity(getPackageManager()) != null ) {
                    startActivity(i);
                } else {
                    Toast.makeText(MainActivity.this, "App is not installed", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}