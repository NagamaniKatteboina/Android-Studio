package com.android.receivingretrofitbroadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BroadcastReceiverRetrofit extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("com.android.sendingBroadcast")) {
            String name = intent.getStringExtra("name");
            String job = intent.getStringExtra("job");
            Toast.makeText(context, "Broadcast received", Toast.LENGTH_SHORT).show();
            Log.d("BroadcastReceived data is : ", "\nname:"+name+"\njob:"+job);
            postData(context,name,job);
        }
    }

    private void postData(Context context, String name, String job) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        User user = new User(name,job);
        Call<ResponseBody> call = apiService.postUser(user);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String responseData = response.body().string();
                    Log.d("RETROFIT", "Post data: "+responseData);
                    Toast.makeText(context, ""+responseData, Toast.LENGTH_SHORT).show();

                    //sending data to second activity
                    Intent intent = new Intent(context,SecondActivity.class);
                    intent.putExtra("response",responseData);
                    context.startActivity(intent);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("RETROFIT", "onResponse: Failed to post data");
            }
        });

    }
}
