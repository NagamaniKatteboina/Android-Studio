package com.android.gamingwebview;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.android.gamingwebview.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private Handler handler = new Handler();
    private int score = 0;
    private boolean gameRunning = false;

    private Runnable endGameRunnable = new Runnable() {
        @Override
        public void run() {
            endGame();
        }
    };

    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set up WebView
        binding.webView.setWebViewClient(new WebViewClient());
        binding.webView.getSettings().setJavaScriptEnabled(true);

        // Start Game Button Listener
        binding.startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame();
            }
        });

        // Play area click listener to increase the score
        binding.playArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gameRunning) {
                    score++;
                    binding.scoreTextView.setText("Score: " + score);
                }
            }
        });
    }

    // Start the game and the 30-second timer
    private void startGame() {
        score = 0;
        binding.scoreTextView.setText("Score: 0");
        binding.startGameButton.setVisibility(View.GONE);
        binding.playArea.setVisibility(View.VISIBLE);
        gameRunning = true;

        // Start a 30-second timer
        handler.postDelayed(endGameRunnable, 10000); // 30 seconds
    }

    // End the game and show the WebView
    private void endGame() {
        gameRunning = false;
        binding.playArea.setVisibility(View.GONE);
        binding.scoreTextView.setVisibility(View.GONE);

        // Show WebView with a batting URL (or any other URL)
        binding.webView.setVisibility(View.VISIBLE);
        binding.webView.loadUrl("https://fxtrading.com/en/promotions/"); // Replace with your desired URL
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(endGameRunnable); // Clean up the handler
    }
}