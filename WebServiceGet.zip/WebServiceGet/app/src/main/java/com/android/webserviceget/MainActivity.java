package com.android.webserviceget;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.webserviceget.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private MyRecyclerViewAdapter dataAdapter;
    private List<ObjectData> dataList;
    //private List<DataClass> userList;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Create the JSON object to send
                    JSONObject jsonData = new JSONObject();
                    jsonData.put("name", binding.editTextName.getText().toString());
                    JSONObject dataObject = new JSONObject();
                    dataObject.put("year", Integer.parseInt(binding.editTextYear.getText().toString()));
                    dataObject.put("price", Double.parseDouble(binding.editTextPrice.getText().toString()));
                    dataObject.put("CPU model", binding.editTextCpuModel.getText().toString());
                    dataObject.put("Hard disk size", binding.editTextHardDiskSize.getText().toString());
                    jsonData.put("data", dataObject);
                    // Execute the AsyncTask to send the data
                    new PostDataTask().execute(jsonData);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Failed to create JSON object", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataList = new ArrayList<>();
        dataAdapter = new MyRecyclerViewAdapter(dataList, this);
        binding.recyclerView.setAdapter(dataAdapter);
        if (hasInternet(this))
        {
            dataList.clear();
            new FetchDataTask().execute("https://api.restful-api.dev/objects");
        }
        else
        {
            Toast.makeText(this, "No Active internet", Toast.LENGTH_SHORT).show();
        }


    }

    private class FetchDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String urlString = strings[0];
            StringBuilder result = new StringBuilder();

            try {
                URL url = new URL(urlString);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                reader.close();
            } catch (Exception e) {
                Log.e("FetchDataTask", "Error", e);
                return null;
            }

            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray jsonArray = new JSONArray(result);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String id = jsonObject.getString("id");

                        String name = jsonObject.getString("name");
                        /*//1st way
                        JSONObject dataObject=jsonObject.optJSONObject("data");
                        DataClass dataclass = null;
                        if (dataObject != null) {
                            String generation = dataObject.optString("color");
                            String price = dataObject.optString("capacity");
                            dataclass = new DataClass(generation,price);
                        }
                        dataList.add(new ObjectData(id, name, dataclass));*/
                        //2nd way
                        // Handle the data object
                        JSONObject dataObject = jsonObject.optJSONObject("data");
                        Map<String, Object> dataMap = new HashMap<>();
                        if (dataObject != null) {
                            JSONArray keys = dataObject.names();
                            if (keys != null) {
                                for (int j = 0; j < keys.length(); j++) {
                                    String key = keys.getString(j);
                                    Object value = dataObject.get(key);
                                    dataMap.put(key, value);
                                }
                            }
                        }
                        dataList.add(new ObjectData(id, name, dataMap));
                    }
                    dataAdapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(MainActivity.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public class PostDataTask extends AsyncTask<JSONObject, Void, String> {

        private static final String POST_URL = "https://api.restful-api.dev/objects";

        @Override
        protected String doInBackground(JSONObject... jsonObjects) {
            HttpURLConnection urlConnection = null;
            StringBuilder result = new StringBuilder();

            try {
                URL url = new URL(POST_URL);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setDoOutput(true);

                // Send the POST data
                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                out.write(jsonObjects[0].toString().getBytes());
                out.flush();
                out.close();

                // Read the response
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
                Log.d("TAG", "doInBackground: "+result);

            } catch (Exception e) {
                Log.e("PostDataTask", "Error", e);
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {

            Log.d("PostDataTask", "Response: " + result);
            // Display the result in the TextView
            try {
                JSONObject jsonResponse = new JSONObject(result);
                String prettyResponse = jsonResponse.toString(4); // Pretty print the JSON with indentation
                binding.textViewResult.setText(prettyResponse);
            } catch (JSONException e) {
                e.printStackTrace();
                binding.textViewResult.setText("Failed to parse response");
            }
        }
    }
    Boolean hasInternet(Context context) {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            Network activeNetwork = connectivityManager.getActiveNetwork();
            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(activeNetwork);

            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return true;
                else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return true;
                else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return true;
                else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
                else return false;
            }

        } else {
            try {
                NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                return networkInfo != null && networkInfo.isConnected();
            } catch (NullPointerException e) {
                return false;
            }
        }

        return false;

    }

}