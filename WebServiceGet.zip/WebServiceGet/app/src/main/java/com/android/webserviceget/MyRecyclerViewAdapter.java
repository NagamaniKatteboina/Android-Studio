package com.android.webserviceget;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Map;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private List<ObjectData> mData;
    private LayoutInflater mInflater;
    private Context context;
    private ItemClickListener mClickListener;

    // data is passed into the constructor
    MyRecyclerViewAdapter(List<ObjectData> data,Context context) {
        this.mInflater = LayoutInflater.from(context);
        this.context=context;
        this.mData = data;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_list, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        ObjectData data = mData.get(position);
        holder.tvName.setText(data.getId() +"."+data.getName());

        /*//1st way
        DataClass dataclass = (DataClass) data.getData();
        if (dataclass != null) {
            String generation = dataclass.getGeneration() != null?"Generatin:" + dataclass.getGeneration():"Generatin:N/A";
            String price = dataclass.getPrice() != null?"Price:" + dataclass.getPrice():"Price:N/A";
            holder.textView.setText(generation+"\n"+price);
        } else {
            holder.textView.setText("No additional data");
        }*/

        //2nd way
        // Display data map as a formatted string
        Map<String, Object> dataMap = data.getData();
        if (dataMap != null && !dataMap.isEmpty()) {
            StringBuilder dataString = new StringBuilder();
            for (Map.Entry<String, Object> entry : dataMap.entrySet()) {
                dataString.append(entry.getKey()).append(": ").append(entry.getValue().toString()).append("\n");
            }
            holder.textView.setText(dataString.toString().trim());
        } else {
            holder.textView.setText("No additional data");
        }
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mData.size();
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvName,textView;
        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.name);
            textView = itemView.findViewById(R.id.dataTextView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }


    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}