package com.android.contactsuploadall;

public class ReadContacts {
    private String contactName;
    private String contactNumber;

    @Override
    public String toString() {
        return "contactName='" + contactName + '\'' +
                ", contactNumber='" + contactNumber +"\n";
    }

    public String getContactName() {
        return contactName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public ReadContacts(String contactName, String contactNumber) {
        this.contactName = contactName;
        this.contactNumber = contactNumber;
    }
}
