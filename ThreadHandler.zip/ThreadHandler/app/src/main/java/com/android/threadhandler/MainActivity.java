package com.android.threadhandler;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.threadhandler.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private Handler handler;
    TextView textView;
    EditText editText;
    Button startButton,stopButton;
    private ProgressBar progressBar;
    MyThread thread1;

    private int totalTasks;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editNum);
        startButton = findViewById(R.id.button);
        stopButton = findViewById(R.id.button2);
        textView = findViewById(R.id.textView);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        handler = new Handler(Looper.getMainLooper()) {
          public void handleMessage(Message msg) {
            if (msg.what == 1) {
                String result = (String) msg.obj;
                textView.setText(result);
            } else if (msg.what == 2) {
                String result = (String) msg.obj;
                textView.setText(result);
                progressBar.setVisibility(View.GONE);
            } else if (msg.what == 3) {
                String interruptionMessage = (String) msg.obj;
                textView.setText(interruptionMessage);
                progressBar.setVisibility(View.GONE);
            }

          }
        };

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                String num = editText.getText().toString();
                try {
                    totalTasks = Integer.parseInt(num);
                } catch (NumberFormatException e) {
                    textView.setText("Invalid input");
                    Log.e("TASKS","Invalid input");
                    progressBar.setVisibility(View.GONE);
                    return;
                }
                thread1 = new MyThread(handler,totalTasks);
                thread1.start();
            }
        });

        stopButton.setOnClickListener(v->{
            if (thread1 != null && thread1.isAlive()) {
                //interrupt the thread
                thread1.interrupt();
            }

        });

    }
}