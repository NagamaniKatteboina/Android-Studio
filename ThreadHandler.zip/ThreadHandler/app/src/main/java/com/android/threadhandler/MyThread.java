package com.android.threadhandler;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class MyThread extends Thread {
    private Handler handler;
    private int totalTasks;

    public MyThread(Handler handler, int totalTasks) {
        this.handler = handler;
        this.totalTasks = totalTasks;
    }

    @Override
    public void run() {
        super.run();
        Message executionStarted = Message.obtain(handler, 1,
                "Execution started");
        Log.d("TASKS", "Execution started");
        handler.sendMessage(executionStarted);
        for (int i = 1; i <= totalTasks; i++) {
            try {
                Thread.sleep(3000);
                Message inProgressMessage = Message.obtain(handler, 1,
                        i + " Tasks completed out of " + totalTasks);

                Log.d("TASKS", "Task " + i +" completed");

                //sending msg to handler
                handler.sendMessage(inProgressMessage);

            } catch (InterruptedException e) {
                //sending interruption message to handler
                Message interruptionMessage = Message.obtain(handler,3,
                        "Thread " +i+" interrupted unable to complete all tasks");
                Log.d("TASKS", "Thread " +i+" interrupted unable to complete all tasks");
                handler.sendMessage(interruptionMessage);
                return;

            }
        }
        //send final result
        Message resultMessage = handler.obtainMessage(2,"All tasks completed");
        handler.sendMessage(resultMessage);

    }
}
