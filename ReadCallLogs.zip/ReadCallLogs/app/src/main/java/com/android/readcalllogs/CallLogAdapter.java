package com.android.readcalllogs;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CallLogAdapter extends RecyclerView.Adapter<CallLogAdapter.ViewHolder> {
    private List<CallLogs> callLogs;

    Context context;
    public CallLogAdapter(List<CallLogs> callLogs) {
        this.callLogs = callLogs;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        CallLogs callLog = callLogs.get(position);
        holder.number.setText(callLog.getNumber());
        holder.type.setText(callLog.getType());
        holder.date.setText(callLog.getDate());
        holder.duration.setText(callLog.getDuration());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context = view.getContext();
                Toast.makeText(context, "contact details of position "+position , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context,SecondActivity.class);
                intent.putExtra("number",callLog.getNumber());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return callLogs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView number, type, date, duration;

        public ViewHolder(View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.tv_number);
            type = itemView.findViewById(R.id.tv_type);
            date = itemView.findViewById(R.id.tv_date);
            duration = itemView.findViewById(R.id.tv_duration);
        }
    }

}