package com.android.smswebview;

public class SmsModel {
    private String Address;
    private String body;

    public SmsModel(String address, String body) {
        Address = address;
        this.body = body;
    }

    public String getAddress() {
        return Address;
    }

    public String getBody() {
        return body;
    }

    @Override
    public String toString() {
        return "SmsModel{" +
                "Address='" + Address + '\'' +
                ", body='" + body + '\'' +
                '}'+"\n";
    }
}
