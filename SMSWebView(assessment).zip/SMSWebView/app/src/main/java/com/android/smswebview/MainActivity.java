package com.android.smswebview;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Telephony;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.smswebview.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<SmsModel> smsList = new ArrayList<>();
    private static final int REQUEST_SMS_CODE = 1;
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, REQUEST_SMS_CODE);
        } else {
            setupWebView();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (REQUEST_SMS_CODE == requestCode && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            setupWebView();
        }
    }

    private void setupWebView() {
        binding.webView.getSettings().setJavaScriptEnabled(true);
        // Load the HTML file from assets
        binding.webView.loadUrl("file:///android_asset/sms.html");
        binding.webView.setVisibility(WebView.VISIBLE);

        // Pass the SMS data to JavaScript after the page is loaded
        binding.webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                List<SmsModel> smsList = fetchSms();  // Fetch SMS only once here
                String smsJson = convertSmsToJson(smsList);
                binding.webView.evaluateJavascript("displaySmsData('" + smsJson + "');", null);
            }
        });
    }

    private List<SmsModel> fetchSms() {
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(Telephony.Sms.CONTENT_URI, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                @SuppressLint("Range") String body = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                SmsModel smsModel = new SmsModel(address, body);
                smsList.add(smsModel);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return smsList;
    }

    private String convertSmsToJson(List<SmsModel> smsList) {
        JSONArray jsonArray = new JSONArray();
        try {
            for (SmsModel sms : smsList) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("address", sms.getAddress());
                jsonObject.put("body", sms.getBody());
                jsonArray.put(jsonObject);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonArray.toString();
    }
}