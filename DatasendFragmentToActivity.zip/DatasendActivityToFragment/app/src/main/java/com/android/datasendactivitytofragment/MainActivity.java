package com.android.datasendactivitytofragment;

import static com.android.datasendactivitytofragment.Fragment1.KEY_EMAIL;
import static com.android.datasendactivitytofragment.Fragment1.KEY_NAME;
import static com.android.datasendactivitytofragment.Fragment1.KEY_PASS;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements PassingData{

    TextView textName,textEmail,textPass;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        textName = findViewById(R.id.textName);
        textEmail = findViewById(R.id.textEmail);
        textPass = findViewById(R.id.textPass);

        // Load the InputFragment into the fragment container
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, new Fragment1())
                    .commit();
        }
    }


    @Override
    public void passingData(Bundle bundle) {
        if (bundle != null) {
            String name = bundle.getString(KEY_NAME);
            String email = bundle.getString(KEY_EMAIL);
            String password = bundle.getString(KEY_PASS);

            textName.setText(name);
            textEmail.setText(email);
            textPass.setText(password);
        }

    }
}