package com.android.datasendactivitytofragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class Fragment1 extends Fragment {


    View view;
    EditText editName,editEmail,editPass;
    String name,email,pass;
    Button button;
    PassingData passingData;

    public static final String KEY_NAME="name";
    public static final String KEY_EMAIL="email";
    public static final String KEY_PASS="pass";
    public static final String KEY_BUNDLE="pass";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_1, container, false);
        editName = view.findViewById(R.id.editName);
        editEmail = view.findViewById(R.id.editEmail);
        editPass = view.findViewById(R.id.editPass);
        button = view.findViewById(R.id.buttonSend);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = editName.getText().toString();
                email = editEmail.getText().toString();
                pass = editPass.getText().toString();


                Bundle bundle= new Bundle();
                bundle.putString(KEY_NAME,name);
                bundle.putString(KEY_EMAIL,email);
                bundle.putString(KEY_PASS,pass);
                if (passingData != null) {
                    passingData.passingData(bundle);
                }

            }
        });
        return  view;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // Ensure the activity implements the interface
        if (context instanceof PassingData) {
            passingData = (PassingData) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement PassingData");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        passingData = null;
    }

}