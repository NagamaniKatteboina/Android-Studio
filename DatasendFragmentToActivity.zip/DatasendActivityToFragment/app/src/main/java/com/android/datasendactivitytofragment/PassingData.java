package com.android.datasendactivitytofragment;

import android.os.Bundle;

public interface PassingData {
    void passingData(Bundle bundle);
}