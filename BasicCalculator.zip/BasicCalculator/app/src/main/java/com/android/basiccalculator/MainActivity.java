package com.android.basiccalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextNumber1, editTextNumber2;
    private Button buttonAdd, buttonSubtract, buttonMultiply, buttonDivide, buttonSquare;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber1 = findViewById(R.id.input1);
        editTextNumber2 = findViewById(R.id.input2);
        buttonAdd = findViewById(R.id.add);
        buttonSubtract = findViewById(R.id.sub);
        buttonMultiply = findViewById(R.id.mul);
        buttonDivide = findViewById(R.id.divide);
        buttonSquare = findViewById(R.id.square);
        textViewResult = findViewById(R.id.result);

        buttonAdd.setOnClickListener(this);

        buttonSubtract.setOnClickListener(this);

        buttonMultiply.setOnClickListener(this);

        buttonDivide.setOnClickListener(this);

        buttonSquare.setOnClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.add:
            {
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double num2 = Double.parseDouble(editTextNumber2.getText().toString());
                double result = num1 + num2;
                textViewResult.setText("Result: " + result);
                break;
            }
            case R.id.sub:
            {
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double num2 = Double.parseDouble(editTextNumber2.getText().toString());
                double result = num1 - num2;
                textViewResult.setText("Result: " + result);
                break;
            }
            case R.id.mul:
            {
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double num2 = Double.parseDouble(editTextNumber2.getText().toString());
                double result = num1 * num2;
                textViewResult.setText("Result: " + result);
                break;
            }
            case R.id.divide:
            {
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double num2 = Double.parseDouble(editTextNumber2.getText().toString());
                if (num2 != 0) {
                    double result = num1 / num2;
                    textViewResult.setText("Result: " + result);
                }
            }
            case R.id.square: {
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double result = num1 * num1;
                textViewResult.setText("Result: " + result);
                break;
            }
            default: {
            }
        }
    }
}