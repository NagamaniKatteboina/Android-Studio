package com.android.contactscalllogsupload;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.contactscalllogsupload.databinding.ActivityMainBinding;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    List<ReadContacts> contactsList = new ArrayList<>();
    List<ReadContacts> filteredContacts = new ArrayList<>();
    List<CallLogs> callLogsList = new ArrayList<>();
    private static final int REQUEST_CONTACT_CODE = 1;
    ActivityMainBinding binding;
    private static final int REQUEST_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //checking Read Contacts permission and upload contacts without user interaction using OkHttp3
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.READ_CONTACTS},REQUEST_CONTACT_CODE);
        } else {
            fetchContactsAndUploadUsingOkhttp3();
        }


        //Checking Permission for CallLogs fetching the calllogs when we click on button means with user interaction
        binding.btnFetchCallLogs.setOnClickListener(v->{
            if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG)!= PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.READ_CALL_LOG},REQUEST_CODE);
            } else {
                fetchCallLogs();
            }
        });

        //Uploading CallLogs with User Interaction using Retrofit
        binding.btnUploadCallLogs.setOnClickListener(v->{
            uploadRetrofit();
        });

    }

    private void fetchContactsAndUploadUsingOkhttp3() {
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null,null);
        if (cursor !=null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                @SuppressLint("Range") String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                contactsList.add(new ReadContacts(name,number));
            } while (cursor.moveToNext());
            Log.d("AllContacts: ", contactsList.toString());
        }
        //Upload contacts using AsyncOkHttp3 withoud userinteraction
        new AsyncOkHttp3ForUpload().execute();
    }

    private class AsyncOkHttp3ForUpload extends AsyncTask<Void,Void,String> {
        @Override
        protected String doInBackground(Void... voids) {
            // filtering to get only 5 entries & Upload only 5 contacts from the list
            if (contactsList.size() > 5) {
                filteredContacts = contactsList.subList(0, 5);
            } else {
                filteredContacts = contactsList;
            }
            Log.d("FILTEREDCONTACTS", filteredContacts.toString());
            OkHttpClient client = new OkHttpClient();
            Gson gson = new Gson();
            String json = gson.toJson(filteredContacts);
            RequestBody requestBody = RequestBody.create(json, MediaType.parse("application/json;charset=utf-8"));
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url("https://jsonplaceholder.typicode.com/posts")
                    .post(requestBody)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.d("OKHTTP3UPLOADCONTACTS", result);
            binding.textView.setText("Uploaded Contacts without user interaction\n"+result);
        }
    }

    private void fetchCallLogs() {
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(CallLog.Calls.CONTENT_URI,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                @SuppressLint("Range") String type = cursor.getString(cursor.getColumnIndex(CallLog.Calls.TYPE));
                @SuppressLint("Range") String duration = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DURATION));
                type = getStringType(Integer.parseInt(type));
                CallLogs calllog = new CallLogs(number,type,duration);
                callLogsList.add(calllog);
            } while (cursor.moveToNext());
            Log.d("CallLogs", "fetchCallLogs: "+callLogsList.toString());
            Toast.makeText(this, "CallLogs Fetched Successfully "+callLogsList.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    private void uploadRetrofit() {
        if (callLogsList.isEmpty()) {
            Toast.makeText(this, "no callLog found to post", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ResponseBody> call = apiService.postCalls(callLogsList);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String result = response.body().string();
                    binding.textView2.setText(result);
                    Log.d("SUCCESSSTATUS", "onResponse: \n"+response.toString());
                    Log.d("RETROFITUPLOADEDCALLLOGS", result);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                binding.textView2.setText(t.getMessage());
            }
        });
    }
    private String getStringType(int type) {
        switch (type) {
            case CallLog.Calls.INCOMING_TYPE: return "Incoming";
            case CallLog.Calls.OUTGOING_TYPE: return "Outgoing";
            case CallLog.Calls.MISSED_TYPE: return "Missedcall";
            default: return "Unknown";
        }
    }

}