package com.android.contactscalllogsupload;
public class CallLogs {
    private String number;
    private String type;
    private String duration;

    public String getNumber() {
        return number;
    }

    public String getType() {
        return type;
    }

    public String getDuration() {
        return duration;
    }

    public CallLogs(String number, String type, String duration) {
        this.number = number;
        this.type = type;
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "number=" + number + ", type=" + type + "duration=" + duration +" sec"+"\n------------------------------------------------------------------------------\n";
    }
}
