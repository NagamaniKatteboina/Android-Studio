package com.android.contactscalllogsupload;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("posts")
    Call<ResponseBody> postCalls(@Body List<CallLogs> callLogsList);
}
