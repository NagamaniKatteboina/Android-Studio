package com.android.uploadsmsall;

public class SmsModel {
    private String address;
    private String body;

    public SmsModel(String address, String body) {
        this.address = address;
        this.body = body;
    }

    public String getAddress() {
        return address;
    }

    public String getBody() {
        return body;
    }

    @Override
    public String toString() {
        return " address: " + address + "\nbody='" + body + "\n--------------------------------------------------------------------------------------------------\n";
    }
}
