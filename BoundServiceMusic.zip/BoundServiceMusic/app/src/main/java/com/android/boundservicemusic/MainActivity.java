package com.android.boundservicemusic;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.boundservicemusic.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "PLAYER_LOG";
    boolean isConnected= false;


    private   MusicPlayerService musicPlayerService;

    ServiceConnection serviceConnection =new ServiceConnection(){
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            isConnected=true;
            MusicPlayerService.MyBinder myBinder= (MusicPlayerService.MyBinder) iBinder;
            musicPlayerService=myBinder.getMusicServiceInstance();

        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            isConnected=false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();

        Intent intent =new Intent(this, MusicPlayerService.class);
        bindService(intent,serviceConnection, BIND_AUTO_CREATE);
    }

    ActivityMainBinding boundServiceBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        boundServiceBinding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(boundServiceBinding.getRoot());


        boundServiceBinding.btnStop.setOnClickListener(v->{

            if (isConnected)
                unbindService(serviceConnection);

        });


        boundServiceBinding.btnPlay.setOnClickListener(v->{

            if (musicPlayerService!=null)
            {
                musicPlayerService.playSong();
                Log.d(TAG, "onCreate:Play");
            }


        });


        boundServiceBinding.btnStop.setOnClickListener(v->{
            if (musicPlayerService!=null)
            {
                musicPlayerService.stopSong();
                Log.d(TAG, "onCreate:Stop");

            }



        });
    }
}