package com.android.boundservicemusic;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class MusicPlayerService extends Service {

    private static final String TAG ="SERVICE_LOGS" ;
    final private  MyBinder myBinder =new MyBinder();
    private MediaPlayer mediaPlayer;

    public class MyBinder extends Binder{
        MusicPlayerService  getMusicServiceInstance()
        {
            return MusicPlayerService.this;
        }

    }
    public MusicPlayerService() {
    }
    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer=MediaPlayer.create(this, R.raw.sample_s);
        mediaPlayer.setLooping(true);
        Log.d(TAG, "onCreate: ");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: ");
        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: ");
        return myBinder;
    }

    public void playSong()
    {
        Log.d(TAG, "playSong: ");
        if (!mediaPlayer.isPlaying())
            mediaPlayer.start();
    }


    public void pauseSong()
    {
        Log.d(TAG, "pauseSong: ");
        if (mediaPlayer.isPlaying())
            mediaPlayer.pause();
    }


    public void stopSong()
    {
        if (mediaPlayer.isPlaying())
            mediaPlayer.start();

    }

    @Override
    public boolean onUnbind(Intent intent) {

        Log.d(TAG, "onUnbind: ");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {

        Log.d(TAG, "onDestroy: ");
        super.onDestroy();
    }
}