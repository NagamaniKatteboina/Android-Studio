package com.android.asynctaskreadwritefile;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "FileIOExample";
    private static final int PERMISSION_REQUEST_CODE = 1;
    private String FILE_NAME ;

    private TextView textView;
    private EditText editText,editFileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editTextInput);
        editFileName = findViewById(R.id.editFileName);
        textView = findViewById(R.id.textView);
        Button writeButton = findViewById(R.id.writeButton);
        Button readButton = findViewById(R.id.readButton);


        writeButton.setOnClickListener(view -> {
            FILE_NAME = editFileName.getText().toString();
            if (FILE_NAME.isEmpty() || !FILE_NAME.endsWith(".txt")) {
                editFileName.setError("Invalid file name. Ensure it ends with .txt");
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    new WriteToFileTask().execute(FILE_NAME, editText.getText().toString());
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                }
            }
        });

        readButton.setOnClickListener(view -> {
            FILE_NAME = editFileName.getText().toString();
            if (FILE_NAME.isEmpty() || !FILE_NAME.endsWith(".txt")) {
                editFileName.setError("Invalid file name. Ensure it ends with .txt");
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    new ReadFromFileTask().execute(FILE_NAME);
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Storage permission granted.");
            } else {
                Log.d(TAG, "Storage permission denied.");
            }
        }
    }

    // AsyncTask to write data to file
    private class WriteToFileTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String fileName = params[0];
            String fileContent = params[1];

            if (fileContent.isEmpty()) {
                return false;
            }
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(fileContent.getBytes());
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                textView.setText("File written successfully.");
            } else {
                textView.setText("Failed to write file bcz input is empty");
            }
        }

    }

    // AsyncTask to read data from file
    private class ReadFromFileTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String fileName = params[0];
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), fileName);
            try (FileInputStream fis = new FileInputStream(file)) {
                int size = fis.available();
                byte[] buffer = new byte[size];
                fis.read(buffer);
                return new String(buffer);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                textView.setText(result);
            } else {
                textView.setText("Failed to read file bcz There is no file");
            }
        }

    }
}