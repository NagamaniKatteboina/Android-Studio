package com.example.sendingbroadcast;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.sendingbroadcast.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    EditText editText1,editText2;
    Button button;

    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = binding.editName.getText().toString();
                String email = binding.editEmail.getText().toString();
                Intent intent = new Intent();
                intent.setAction("com.example.broadcast.SEND_MESSAGE");
                intent.putExtra("kname",name);
                intent.putExtra("kemail",email);
                sendBroadcast(intent);
            }
        });

    }
}