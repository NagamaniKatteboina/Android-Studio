package com.android.uploadimageintoserver;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {

    @POST("/posts")
    Call<Void> uploadFile(@Body UploadImage uploadImage);
}
