package com.android.uploadimageintoserver;

import android.util.Base64;
import android.util.Log;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static Retrofit retrofit = null;
    private static String POST_URL="https://jsonplaceholder.typicode.com/";
    private static String encodeServer = Base64.encodeToString(POST_URL.getBytes(), Base64.DEFAULT);
    private static String decodedUrl = new String(Base64.decode(encodeServer, Base64.DEFAULT));
    static Retrofit getClient() {
        if (retrofit==null)
        {
            Log.d("ENCODEDSERVERURL", ""+encodeServer);
            Log.d("DECODEDSERVERURL", ""+decodedUrl);
            retrofit = new Retrofit.Builder()
                    .baseUrl(decodedUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
