package com.android.uploadimageintoserver;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.uploadimageintoserver.databinding.ActivityMainBinding;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 1;
    Uri videoUri;
    private String base64Video;  // Store Base64 encoded video
    private static final String TAG = "MainActivity";
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.selectFile.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION);
            } else {
                selectVideo();
            }
        });
        binding.uploadButton.setOnClickListener(v -> uploadVideo());
        binding.uploadButtonUsingVolley.setOnClickListener(v -> uploadVideoUsingVolley());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION && grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            selectVideo();
        } else {
            Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    // Launch the file picker to select a video
    private void selectVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("video/*");
        startActivityForResult(intent,1);
    }

    private boolean isVideoProcessed = false;  // Flag to ensure video is processed only once

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && !isVideoProcessed) {
            videoUri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(videoUri);
                byte[] videoBytes = new byte[inputStream.available()];
                inputStream.read(videoBytes);

                // Encode video to Base64
                base64Video = Base64.encodeToString(videoBytes, Base64.DEFAULT);
                Log.d("VIDEOENCODE", "Encoded URL (Base64): " + base64Video.substring(0,50));

                // Decode Base64 back to bytes (just for logging)
                byte[] decodedBytes = Base64.decode(base64Video, Base64.DEFAULT);
                Log.d("VIDEODECODE", "Decoded URL from Base64: " + new String(decodedBytes).substring(0,50));

                isVideoProcessed = true;  // Mark video as processed

            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "Error encoding video: " + e.getMessage());
            }
        }
    }
    // Upload the Base64 encoded video to the server
    private void uploadVideo() {
        if (base64Video == null) {
            Toast.makeText(this, "Please select a video first", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        // Prepare the request body
        UploadImage request = new UploadImage("Video Upload", base64Video);

        // Make the API call to upload
        apiService.uploadFile(request).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Video uploaded successfully.", Toast.LENGTH_SHORT).show();
                    Log.d("FILEUPLOAD", "Video uploaded successfully.");
                } else {
                    Log.e("FILEUPLOAD", "Upload failed: ");
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("FILEUPLOAD", "Upload error: " + t.getMessage());
                Toast.makeText(MainActivity.this, "Error uploading video", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void uploadVideoUsingVolley() {
        if (videoUri == null) {
            Toast.makeText(this, "Please select a video first", Toast.LENGTH_SHORT).show();
            return;
        }
        String uploadUrl = "https://jsonplaceholder.typicode.com/posts"; // Replace with your server URL
        String encodedUrl = Base64.encodeToString(uploadUrl.getBytes(), Base64.DEFAULT);
        Log.d("VOLLEYENCODE", ""+encodedUrl);
        String decodedUrl = new String(Base64.decode(encodedUrl, Base64.DEFAULT));
        Log.d("VOLLEYDECODE", ""+decodedUrl);
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, decodedUrl,
                response -> {
                    Toast.makeText(MainActivity.this, "Upload successful using volley", Toast.LENGTH_SHORT).show();
                    Log.d("VOLLEYUPLOAD", "uploadVideoUsingVolley");
                },
                error -> {
                    Toast.makeText(MainActivity.this, "Upload failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("VOLLEYUPLOAD", "Upload failed");
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("video", videoUri.toString()); // This is just a placeholder. You need to handle file upload properly.
                return params;
            }
        };
        requestQueue.add(stringRequest);

    }

}