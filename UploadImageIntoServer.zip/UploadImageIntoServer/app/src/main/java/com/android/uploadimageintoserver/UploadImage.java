package com.android.uploadimageintoserver;

public class UploadImage {
    private String title;
    private  String video;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public UploadImage(String title, String video) {
        this.title = title;
        this.video = video;
    }
}
