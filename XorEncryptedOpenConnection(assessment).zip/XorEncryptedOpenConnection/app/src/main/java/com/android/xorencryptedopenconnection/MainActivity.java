package com.android.xorencryptedopenconnection;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    //Encrypted url using XOR
    private final String HEX_ENCRYPTED_URL = "050d2715595d4a033c125709183d0206000a0138121c0f0a3a11065c061b26";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new FetchDataTask().execute();
    }

    private class FetchDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String result = "";
            try {
                //decrypting the encrypted url
                String decryptedUrl = decryptXor(fromHex(HEX_ENCRYPTED_URL), "mySecretKey"); // Decrypt the hexadecimal URL
                Log.d("Decrypt", decryptedUrl);
                URL url = new URL(decryptedUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    result += line;
                }
                reader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            // Log or display the result
            System.out.println("Response: " + result);
        }
    }

    // XOR decryption method
    private String decryptXor(String encrypted, String key) {
        char[] keyChars = key.toCharArray();
        char[] encryptedChars = encrypted.toCharArray();
        char[] decrypted = new char[encryptedChars.length];
        for (int i = 0; i < encryptedChars.length; i++) {
            decrypted[i] = (char) (encryptedChars[i] ^ keyChars[i % keyChars.length]);
        }
        return new String(decrypted);
    }

    // Converting to string from hexadecimal
    private String fromHex(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i+1), 16));
        }
        return new String(data);
    }
}

