package com.example.receivingbroadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MessageReceiver extends BroadcastReceiver {
    /*interface ResultInterface {
        public void onResult(String result);
    }

    ResultInterface resultInterface;*/
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.example.broadcast.SEND_MESSAGE")) {
            String name = intent.getStringExtra("kname");
            String email = intent.getStringExtra("kemail");
            String result = "Name: " + (name) +"\nEmail: "+email;
            Toast.makeText(context, ""+result, Toast.LENGTH_SHORT).show();
            //MainActivity.textView.setText(result);

            /*if (resultInterface != null) {
                resultInterface.onResult(result);
            }*/
        }
    }
}