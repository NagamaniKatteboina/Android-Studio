package com.android.parcelabledatapassing;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {

    TextView textView;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.nameTextView);

        // Get the user data from the intent
        User user = getIntent().getParcelableExtra("user_data");

        if (user != null) {
            textView.setText(" "+user.getName()+"  "+user.getEmail()+"  "+user.getDob());
            if(user.getImage() != null) {
                imageView = findViewById(R.id.imageView);
                imageView.setImageBitmap(user.getImage());
            } else {
                Toast.makeText(this, "Unable to select the image", Toast.LENGTH_SHORT).show();
            }

        }
    }
}