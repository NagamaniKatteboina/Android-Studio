package com.android.sendbroadcastretrofit;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.sendbroadcastretrofit.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name =binding.editName.getText().toString();
                String job =binding.editJob.getText().toString();

                if(name.isEmpty()) {
                    binding.editName.setError("Required field");
                    return;
                }
                if(job.isEmpty()) {
                    binding.editJob.setError("Required field");
                    return;
                }
                Intent intent = new Intent("com.android.sendingBroadcast");
                intent.putExtra("name",name);
                intent.putExtra("job",job);
                Toast.makeText(MainActivity.this, "Broadcast sended", Toast.LENGTH_SHORT).show();
                Log.d("SENDBROADCAST", "Broadcast sended");
                sendBroadcast(intent);
            }
        });

    }
}