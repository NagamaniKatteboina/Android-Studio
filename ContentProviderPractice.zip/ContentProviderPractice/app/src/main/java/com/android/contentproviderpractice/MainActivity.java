package com.android.contentproviderpractice;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telecom.TelecomManager;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.contentproviderpractice.databinding.ActivityMainBinding;

import java.security.Permission;

public class MainActivity extends AppCompatActivity {

    private static final int READ_CONTACTS_CODE = 1;
    private static final int READ_SMS_CODE = 1;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnReadContacts.setOnClickListener(v-> {
            //checkPermission();
            checkPermissionSms();
        });
    }

    private void checkPermissionSms() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.READ_SMS},READ_SMS_CODE);
        } else {
            readSms();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == READ_SMS_CODE && grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            readSms();
        } else {
            binding.textView.setText("permission denied");
        }
    }

    private void readSms() {
        StringBuilder sms = new StringBuilder();
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(Telephony.Sms.CONTENT_URI,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                @SuppressLint("Range") String subject = cursor.getString(cursor.getColumnIndex(Telephony.Sms.SUBJECT));
                @SuppressLint("Range") String body = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                sms.append("address: "+address).append("\nsubject: "+subject)
                        .append("\nBody:"+body).append("\n\n");
            }
            binding.textView.setText(sms.toString());
        } else {
            binding.textView.setText("failed to fetch sms because sms is empty");
        }
    }

    /*private void checkPermission() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS},READ_CONTACTS_CODE);
        } else {
            readContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //readContacts();
        }
    }



    private void readContacts() {
        StringBuilder contacts = new StringBuilder();
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                @SuppressLint("Range") String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                contacts.append("Contact Name:"+name).append("\n").append("Number:"+number).append("\n\n\n");

            } while(cursor.moveToNext());
            binding.textView.setText(contacts.toString());
        } else {
            binding.textView.setText("Failed to fetch Contacts");
        }

    }*/

}