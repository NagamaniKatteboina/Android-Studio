package com.android.myretrofit;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {
    @GET("/objects")
    Call<List<ListOfObjects>> getListOfObjects();
    @POST("/objects")
    Call<ListOfObjects> postObject(@Body ListOfObjects postData);

}
