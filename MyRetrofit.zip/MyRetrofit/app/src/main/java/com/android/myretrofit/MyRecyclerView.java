package com.android.myretrofit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyRecyclerView extends RecyclerView.Adapter<MyRecyclerView.ViewHolder> {
    private List<ListOfObjects> objectList;

    public MyRecyclerView(List<ListOfObjects> objectList) {
        this.objectList = objectList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_object, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ListOfObjects objectData = objectList.get(position);

        holder.nameTextView.setText(objectData.getName());
        holder.idTextView.setText(String.valueOf(objectData.getId()));

        // Check if data is null before calling toString()
        if (objectData.getData() != null) {
            holder.dataTextView.setText(objectData.getData().toString());
        } else {
            holder.dataTextView.setText("No data available");  // Handle null case with a placeholder
        }
    }

    @Override
    public int getItemCount() {
        return objectList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTextView, idTextView, dataTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            idTextView = itemView.findViewById(R.id.idTextView);
            dataTextView = itemView.findViewById(R.id.dataTextView);
        }
    }
}