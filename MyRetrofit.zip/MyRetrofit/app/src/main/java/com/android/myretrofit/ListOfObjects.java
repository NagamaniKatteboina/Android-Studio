package com.android.myretrofit;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class ListOfObjects {
    @SerializedName("id")
    private String id;

    @SerializedName("name")
    private String name;

    @SerializedName("data")
    private Map<String, Object> data; // Using Map to handle varying data keys

    public ListOfObjects(String name, Map<String, Object> dataMap) {
        this.name = name;
        this.data = dataMap;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Map<String, Object> getData() {
        return data;
    }
}