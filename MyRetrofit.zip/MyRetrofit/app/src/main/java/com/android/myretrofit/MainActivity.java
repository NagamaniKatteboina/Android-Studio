package com.android.myretrofit;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.myretrofit.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private MyRecyclerView adapter;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postObjectData();
            }
        });

        binding.getButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchObjects();
            }
        });
    }

    private void fetchObjects() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<ListOfObjects>> call = apiService.getListOfObjects();

        call.enqueue(new Callback<List<ListOfObjects>>() {
            @Override
            public void onResponse(Call<List<ListOfObjects>> call, Response<List<ListOfObjects>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ListOfObjects> objectList = response.body();
                    adapter = new MyRecyclerView(objectList);
                    binding.recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<ListOfObjects>> call, Throwable t) {
                Log.e("MainActivity", "Error fetching data", t);
            }
        });
    }
    private void postObjectData() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        // Prepare the data for the post request
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("color", binding.editColor.getText().toString());
        dataMap.put("capacity", binding.editCapacity.getText().toString());

        ListOfObjects postData = new ListOfObjects(binding.editTextName.getText().toString(), dataMap);

        // Make the POST request
        Call<ListOfObjects> call = apiService.postObject(postData);
        call.enqueue(new Callback<ListOfObjects>() {
            @Override
            public void onResponse(Call<ListOfObjects> call, Response<ListOfObjects> response) {
                if (response.isSuccessful()) {
                    ListOfObjects responseData = response.body();
                    String id = String.valueOf(responseData.getId());
                    Log.d("ID", "onResponse: "+id);
                    binding.textViewResult.setText("Posted successfully: \nId:"+id+"\nName:" +responseData.getName()+"\nData:"+responseData.getData());
                    Log.d("POST_SUCCESS", "Posted data: " + "\nName:" +responseData.getName()+"\nData:"+responseData.getData());
                } else {
                    binding.textViewResult.setText("Error code: " + response.code());
                    Log.e("POST_ERROR", "Error code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<ListOfObjects> call, Throwable t) {
                binding.textViewResult.setText("Failed to post data");
                Log.e("POST_FAILURE", "Failed to post data", t);
            }
        });
    }
}
