package com.android.calculationbroadcast;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements ResultInterface{
    EditText editNum1,editNum2;

    TextView textView;

    private CalculationReceiver calculationReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editNum1 = findViewById(R.id.editNum1);
        editNum2 = findViewById(R.id.editNum2);
        textView = findViewById(R.id.textResult);

        calculationReceiver = new CalculationReceiver();
        calculationReceiver.setResultInterface(this);
        findViewById(R.id.sendButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 = Integer.parseInt(editNum1.getText().toString().trim());
                int num2 = Integer.parseInt(editNum2.getText().toString().trim());
                Intent intent = new Intent();
                intent.setAction("com.android.CALCULATION_ACTION");
                intent.putExtra("number1",num1);
                intent.putExtra("number2",num2);
                sendBroadcast(intent);
            }
        });

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.android.CALCULATION_ACTION");
        registerReceiver(calculationReceiver,intentFilter);

    }


    @Override
    public void onResult(String result) {
        Snackbar.make(findViewById(R.id.main),result,Snackbar.LENGTH_LONG).show();
        textView.setText(result);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(calculationReceiver);
    }
}