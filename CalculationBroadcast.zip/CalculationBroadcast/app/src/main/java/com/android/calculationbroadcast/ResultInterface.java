package com.android.calculationbroadcast;

public interface ResultInterface {
    void onResult(String result);
}
