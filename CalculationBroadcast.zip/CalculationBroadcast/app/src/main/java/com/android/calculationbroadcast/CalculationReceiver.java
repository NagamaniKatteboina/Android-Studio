package com.android.calculationbroadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CalculationReceiver extends BroadcastReceiver {

    private ResultInterface resultInterface;
    String result;

    public ResultInterface getResultInterface() {

        return resultInterface;
    }

    public void setResultInterface(ResultInterface resultInterface) {
        this.resultInterface = resultInterface;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.android.CALCULATION_ACTION") && intent != null) {
            int num1 = intent.getIntExtra("number1",0);
            int num2 = intent.getIntExtra("number2",0);

            int add = num1+num2;
            int sub = num1-num2;
            int mul = num1*num2;
            double div = num1/num2;
            result = "Add: "+Integer.toString(add) +"\nSub: "+Integer.toString(sub)
                    +"\nMul: "+Integer.toString(mul)+"\ndiv: "+Double.toString(div);
            getResultInterface().onResult(result);

        }
    }
}
