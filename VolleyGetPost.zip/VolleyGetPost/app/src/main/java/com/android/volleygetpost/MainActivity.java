package com.android.volleygetpost;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volleygetpost.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    final  static String API_URL="https://api.restful-api.dev/objects";
    RequestQueue requestQueue;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.buttonUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Example data
                String name = "John Doe";
                String email = "johndoe@example.com";
                Bitmap imageBitmap = getImageBitmap(); // Replace with actual image bitmap

                postImage(name, email, imageBitmap);
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        // Execute the GET request using Volley
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, API_URL, null, new Response.Listener<JSONArray>() {

                    @Override
                    public void onResponse(JSONArray response) {
                        //this is displaying raw data
                        /*if (response != null) {
                            binding.textView.setText(response.toString());
                        }*/
                        binding.progressBar.setVisibility(View.GONE);
                        //using stringbuilder
                        try {
                            // Process the JSON array response
                            StringBuilder result = new StringBuilder();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject object = response.getJSONObject(i);
                                result.append(object.getString("id")).append("\n");
                                result.append(object.getString("name")).append("\n");

                                JSONObject data = object.optJSONObject("data");
                                if (data != null) {
                                    result.append(data.toString()).append("\n");
                                } else {
                                    result.append("Data: null\n");
                                }

                                result.append("\n");
                            }
                            // Display the result in the TextView
                            binding.textView.setText(result.toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this, "Failed to process response", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        binding.progressBar.setVisibility(View.GONE);
                        // Handle error
                        binding.textView.setText("Error: " + error.getMessage());
                    }
                });
        // Add the request to the RequestQueue
        requestQueue.add(jsonArrayRequest);

    }

    private void postImage(String name, String email, Bitmap imageBitmap) {
        String url = "https://www.filestackapi.com/api/store/S3?key=YOUR_API_KEY";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle response
                        Log.d("Response", response);
                        Toast.makeText(MainActivity.this, "Response: " + response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error
                        Log.e("Error", error.toString());
                        Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("email", email);
                params.put("image", bitmapToString(imageBitmap)); // Convert bitmap to base64
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private String bitmapToString(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private Bitmap getImageBitmap() {
        // Example: Loading a sample image from drawable
        return BitmapFactory.decodeResource(getResources(), R.drawable.sample_image);
    }
}