package com.android.sqlitetask;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.sqlitetask.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private  DbHelper helper;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        helper = new DbHelper(this,"mydb",null,1);
        binding.btnInsert.setOnClickListener( v-> {
            insert();
        });
    }

    private void insert() {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",binding.etName.getText().toString());
        values.put("mobile_number",binding.etMobile.getText().toString());
        values.put("address",binding.etAddress.getText().toString());
        values.put("loan_number",binding.etLoanNumber.getText().toString());
        values.put("loan_amount",binding.etLoanAmount.getText().toString());
        db.insert("student",null,values);
        Intent intent = new Intent(this,SecondActivity.class);
        intent.putExtra("key","record adding to table\nwait for sometime.....");
        startActivity(intent);
    }
}