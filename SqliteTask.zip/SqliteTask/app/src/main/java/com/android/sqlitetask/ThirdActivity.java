package com.android.sqlitetask;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.sqlitetask.databinding.ActivityThirdBinding;

public class ThirdActivity extends AppCompatActivity {

    private DbHelper helper;
    ActivityThirdBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityThirdBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        helper = new DbHelper(this,"mydb",null,1);
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query("student",null,null,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            StringBuilder stringbuilder = new StringBuilder();
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") String mobile_number = cursor.getString(cursor.getColumnIndex("mobile_number"));
                @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex("address"));
                @SuppressLint("Range") String loan_number = cursor.getString(cursor.getColumnIndex("loan_number"));
                @SuppressLint("Range") String loan_amount = cursor.getString(cursor.getColumnIndex("loan_amount"));
                stringbuilder.append("Name :" + name + "\nMobile_number :" + mobile_number + "\nAddress : " + address + "\nLoan_number: " + loan_number + "\nLoan_amount: " + loan_amount + "\n--------------------------------------------------------------------------------------------------\n");
            } while (cursor.moveToNext());
            binding.textView.setText(stringbuilder.toString());
        } else {
            binding.textView.setText("No reacords found");
        }
    }
}