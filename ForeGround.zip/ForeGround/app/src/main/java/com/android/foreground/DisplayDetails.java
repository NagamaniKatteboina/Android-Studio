package com.android.foreground;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.foreground.databinding.ActivityDisplayDetailsBinding;

public class DisplayDetails extends AppCompatActivity {

    ActivityDisplayDetailsBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDisplayDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String phoneNumber = intent.getStringExtra("phoneNumber");
        String email = intent.getStringExtra("email");
        String password = intent.getStringExtra("password");

        if (name != null && phoneNumber != null && email != null && password!=null) {
            binding.textView.setText("User Details");
            binding.textName.setText("Name: "+name);
            binding.textPhone.setText("PhoneNumber: "+phoneNumber);
            binding.textEmail.setText("Email: "+email);
            binding.textPassword.setText("Password: "+password);
            //binding.startButton.setText("again StartForeground");
        }

        binding.button.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, MainActivity.class);
            startActivity(intent1);
        });
    }
}