package com.android.foreground;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class DetailsService extends Service {

    private static final int NOTIFICATION_ID = 120;
    private static final String CHANNEL_ID = "1001";

    private NotificationManager notificationManager;
    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @SuppressLint("ForegroundServiceType")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                createServiceNotificationChannel();

                Intent notificationItent = new Intent(DetailsService.this,DisplayDetails.class);
                notificationItent.putExtra("name",intent.getStringExtra("name"));
                notificationItent.putExtra("phoneNumber",intent.getStringExtra("phoneNumber"));
                notificationItent.putExtra("email",intent.getStringExtra("email"));
                notificationItent.putExtra("password",intent.getStringExtra("password"));

                PendingIntent pendingIntent = PendingIntent.getActivity(DetailsService.this,0,notificationItent,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                Notification notification = new NotificationCompat.Builder(DetailsService.this,CHANNEL_ID)
                        .setContentTitle("UserDetails")
                        .setContentText("click here to view details")
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentIntent(pendingIntent)
                        .build();
                startForeground(NOTIFICATION_ID,notification);
            }
        });
        thread.start();


        //after 5000 milliseconds notification disappears
        doTask();
        return START_NOT_STICKY;
    }
    private void createServiceNotificationChannel() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,"Foreground Service",NotificationManager.IMPORTANCE_DEFAULT);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

            notificationManager.createNotificationChannel(channel);
        }

    }

    private void doTask() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(20000);
                    stopForeground(true);
                    stopSelf();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
