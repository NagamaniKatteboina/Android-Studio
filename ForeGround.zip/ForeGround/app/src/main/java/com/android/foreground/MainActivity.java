package com.android.foreground;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.foreground.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.startButton.setOnClickListener(v -> {
            String name = binding.editName.getText().toString();
            String phoneNumber = binding.editPhone.getText().toString();
            String email = binding.editEmail.getText().toString();
            String password = binding.editPassword.getText().toString();
            Intent intent = new Intent(this,DetailsService.class);
            intent.putExtra("name",name);
            intent.putExtra("phoneNumber",phoneNumber);
            intent.putExtra("email",email);
            intent.putExtra("password",password);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            }

        });

        binding.clearButton.setOnClickListener(v -> {
            binding.editName.setText("");
            binding.editPhone.setText("");
            binding.editEmail.setText("");
            binding.editPassword.setText("");
            binding.startButton.setText("Start Foreground");
        });
    }
}