package com.android.datatransfer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Activity2 extends AppCompatActivity {

    TextView textName,textPass,textEmail,textPhoneNumber,textAddress;

    String name2,email2,password2,phonenumber2,address2;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textName = findViewById(R.id.textName);
        textPass = findViewById(R.id.textPass);
        textEmail = findViewById(R.id.textEmail);
        textPhoneNumber = findViewById(R.id.textPhoneNumber);
        textAddress = findViewById(R.id.textAddress);

        Intent i = getIntent();
        String name = i.getStringExtra("name");
        String password = i.getStringExtra("pass");
        String email = i.getStringExtra("email");
        String phoneNumber = i.getStringExtra("phoneNumber");
        String address = i.getStringExtra("address");

        textName.setText("Name: "+name);
        textPass.setText("Password: " + password);
        textEmail.setText("Email: "+email);
        textPhoneNumber.setText("PhoneNumber: "+phoneNumber);
        textAddress.setText("Address: "+address);


        //passing data to 3rd activity
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name2 = textName.getText().toString();
                password2 = textPass.getText().toString();
                email2 = textEmail.getText().toString();
                phonenumber2 = textPhoneNumber.getText().toString();
                address2 = textAddress.getText().toString();

                Intent i = new Intent(getApplicationContext(), Activity3.class);
                i.putExtra("name", name2);
                i.putExtra("pass", password2);
                i.putExtra("email", email2);
                i.putExtra("phoneNumber",phonenumber2);
                i.putExtra("address",address2);
                startActivity(i);
            }
        });

    }
}