package com.android.datatransfer;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Activity3 extends AppCompatActivity {

    TextView textName,textPass,textEmail,textPhoneNumber,textAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textName = findViewById(R.id.textName);
        textPass = findViewById(R.id.textPass);
        textEmail = findViewById(R.id.textEmail);
        textPhoneNumber = findViewById(R.id.textPhoneNumber);
        textAddress = findViewById(R.id.textAddress);

        Intent i = getIntent();
        String name = i.getStringExtra("name");
        String password = i.getStringExtra("pass");
        String email = i.getStringExtra("email");
        String phoneNumber = i.getStringExtra("phoneNumber");
        String address = i.getStringExtra("address");

        textName.setText("Name: "+name);
        textPass.setText("Password: " + password);
        textEmail.setText("Email: "+email);
        textPhoneNumber.setText("PhoneNumber: "+phoneNumber);
        textAddress.setText("Address: "+address);
    }
}