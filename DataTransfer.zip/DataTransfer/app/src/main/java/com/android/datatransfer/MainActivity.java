package com.android.datatransfer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText editName,editPass,editEmail,editPhonenumber,editAddress;
    Button button;
    String name,email,password,phonenumber,address;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editName = findViewById(R.id.editName);
        editPass = findViewById(R.id.editPassword);
        editEmail = findViewById(R.id.editEmail);
        editPhonenumber = findViewById(R.id.editNumber);
        editAddress = findViewById(R.id.editAddress);

        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = editName.getText().toString();
                password = editPass.getText().toString();
                email = editEmail.getText().toString();
                phonenumber = editPhonenumber.getText().toString();
                address = editAddress.getText().toString();

                if (isValidated()) {
                    Intent i = new Intent(getApplicationContext(), Activity2.class);
                    i.putExtra("name", name);
                    i.putExtra("pass", password);
                    i.putExtra("email", email);
                    i.putExtra("phoneNumber",phonenumber);
                    i.putExtra("address",address);
                    startActivity(i);
                }

            }

            private boolean isValidated() {
                //validation for name
                if (!name.isEmpty()) {
                    if (name.length() < 4) {
                        editName.setError("name length should be more than 4 char");
                        return false;
                    }
                } else {
                    editName.setError("name is required");
                    return false;
                }

                //password validation
                if (!password.isEmpty()) {
                    if (password.length() < 4) {
                        editPass.setError("Length more than 4 char");
                        return false;
                    }
                } else {
                    editPass.setError("password is required");
                    return false;
                }

                //email validation
                if (!email.isEmpty()) {
                    if (!email.contains("@") || email.length() < 4) {
                        editEmail.setError("Enter valid email");
                        return false;
                    }
                } else {
                    editEmail.setError("email is required");
                    return false;
                }

                //phonenumber validation
                if (!phonenumber.isEmpty()) {
                    if (phonenumber.length() < 4) {
                        editPhonenumber.setError("phonenumber length should be more than 4 char");
                        return false;
                    }
                } else {
                    editPhonenumber.setError("phonenumber is required");
                    return false;
                }

                //address validation
                if (!address.isEmpty()) {
                    if (address.length() < 4) {
                        editAddress.setError("Address length should be more than 4 char");
                        return false;
                    }

                } else {
                    editAddress.setError("Address is required");
                    return false;
                }
                return true;
            }
        });

    }
}